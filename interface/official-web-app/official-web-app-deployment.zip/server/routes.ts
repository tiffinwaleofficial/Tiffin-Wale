import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from 'ws';
import { z } from 'zod';

// Define validation schemas for our forms
const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters long"),
  email: z.string().email("Please provide a valid email address"),
  message: z.string().min(10, "Message must be at least 10 characters long"),
});

const testimonialFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters long"),
  profession: z.string().optional(),
  rating: z.number().min(1).max(5),
  testimonial: z.string().min(10, "Testimonial must be at least 10 characters long"),
  imageUrl: z.string().optional(),
});

const feedbackFormSchema = z.object({
  email: z.string().email("Please provide a valid email address"),
  type: z.enum(['suggestion', 'complaint', 'question', 'other']),
  feedback: z.string().min(10, "Feedback must be at least 10 characters long"),
  rating: z.number().min(1).max(5).optional(),
});

// Create a WebSocket clients collection for real-time updates
type Client = {
  ws: WebSocket;
  id: string;
};

const clients: Client[] = [];

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Initialize WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // WebSocket connection handler
  wss.on('connection', (ws) => {
    const id = Math.random().toString(36).substring(2, 15);
    clients.push({ ws, id });
    
    console.log(`WebSocket client connected: ${id}`);
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({ 
      type: 'connection', 
      message: 'Connected to TiffinWale API', 
      id 
    }));
    
    // Handle incoming messages
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message from client:', data);
        
        // Echo back to the client
        ws.send(JSON.stringify({
          type: 'echo',
          data
        }));
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      const index = clients.findIndex(client => client.id === id);
      if (index !== -1) {
        clients.splice(index, 1);
      }
      console.log(`WebSocket client disconnected: ${id}`);
    });
  });
  
  // Broadcast message to all connected clients
  const broadcastMessage = (type: string, data: any) => {
    const message = JSON.stringify({ type, data });
    clients.forEach(client => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(message);
      }
    });
  };
  
  // API Routes
  
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.status(200).json({ status: 'ok', message: 'TiffinWale API is running' });
  });
  
  // Contact form submission
  app.post('/api/contact', async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const result = contactFormSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          errors: result.error.errors 
        });
      }
      
      const data = result.data;
      
      // Here you would typically store the contact form data
      // For now, we'll just log it
      console.log('Contact form submission:', data);
      
      // Broadcast to connected clients
      broadcastMessage('newContact', {
        id: Date.now().toString(),
        ...data,
        timestamp: new Date().toISOString()
      });
      
      return res.status(200).json({ 
        success: true, 
        message: 'Thank you for contacting us! We will get back to you shortly.' 
      });
    } catch (error) {
      console.error('Error processing contact form:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred while processing your request.' 
      });
    }
  });
  
  // Testimonial submission
  app.post('/api/testimonial', async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const result = testimonialFormSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          errors: result.error.errors 
        });
      }
      
      const data = result.data;
      
      // Here you would typically store the testimonial data
      // For now, we'll just log it
      console.log('Testimonial submission:', data);
      
      // Broadcast to connected clients
      broadcastMessage('newTestimonial', {
        id: Date.now().toString(),
        ...data,
        timestamp: new Date().toISOString()
      });
      
      return res.status(200).json({ 
        success: true, 
        message: 'Thank you for your testimonial! Your feedback helps us improve our service.' 
      });
    } catch (error) {
      console.error('Error processing testimonial:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred while processing your testimonial.' 
      });
    }
  });
  
  // Feedback submission
  app.post('/api/feedback', async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const result = feedbackFormSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          errors: result.error.errors 
        });
      }
      
      const data = result.data;
      
      // Here you would typically store the feedback data
      // For now, we'll just log it
      console.log('Feedback submission:', data);
      
      // Broadcast to connected clients
      broadcastMessage('newFeedback', {
        id: Date.now().toString(),
        ...data,
        timestamp: new Date().toISOString()
      });
      
      return res.status(200).json({ 
        success: true, 
        message: 'Thank you for your feedback! We appreciate your input.' 
      });
    } catch (error) {
      console.error('Error processing feedback:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred while processing your feedback.' 
      });
    }
  });

  return httpServer;
}
