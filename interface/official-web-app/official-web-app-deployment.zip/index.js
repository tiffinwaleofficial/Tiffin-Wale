// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { z } from "zod";
var contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters long"),
  email: z.string().email("Please provide a valid email address"),
  message: z.string().min(10, "Message must be at least 10 characters long")
});
var testimonialFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters long"),
  profession: z.string().optional(),
  rating: z.number().min(1).max(5),
  testimonial: z.string().min(10, "Testimonial must be at least 10 characters long"),
  imageUrl: z.string().optional()
});
var feedbackFormSchema = z.object({
  email: z.string().email("Please provide a valid email address"),
  type: z.enum(["suggestion", "complaint", "question", "other"]),
  feedback: z.string().min(10, "Feedback must be at least 10 characters long"),
  rating: z.number().min(1).max(5).optional()
});
var clients = [];
async function registerRoutes(app2) {
  const httpServer = createServer(app2);
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  wss.on("connection", (ws) => {
    const id = Math.random().toString(36).substring(2, 15);
    clients.push({ ws, id });
    console.log(`WebSocket client connected: ${id}`);
    ws.send(JSON.stringify({
      type: "connection",
      message: "Connected to TiffinWale API",
      id
    }));
    ws.on("message", (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log("Received message from client:", data);
        ws.send(JSON.stringify({
          type: "echo",
          data
        }));
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    });
    ws.on("close", () => {
      const index = clients.findIndex((client) => client.id === id);
      if (index !== -1) {
        clients.splice(index, 1);
      }
      console.log(`WebSocket client disconnected: ${id}`);
    });
  });
  const broadcastMessage = (type, data) => {
    const message = JSON.stringify({ type, data });
    clients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(message);
      }
    });
  };
  app2.get("/api/health", (req, res) => {
    res.status(200).json({ status: "ok", message: "TiffinWale API is running" });
  });
  app2.post("/api/contact", async (req, res) => {
    try {
      const result = contactFormSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          success: false,
          errors: result.error.errors
        });
      }
      const data = result.data;
      console.log("Contact form submission:", data);
      broadcastMessage("newContact", {
        id: Date.now().toString(),
        ...data,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return res.status(200).json({
        success: true,
        message: "Thank you for contacting us! We will get back to you shortly."
      });
    } catch (error) {
      console.error("Error processing contact form:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while processing your request."
      });
    }
  });
  app2.post("/api/testimonial", async (req, res) => {
    try {
      const result = testimonialFormSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          success: false,
          errors: result.error.errors
        });
      }
      const data = result.data;
      console.log("Testimonial submission:", data);
      broadcastMessage("newTestimonial", {
        id: Date.now().toString(),
        ...data,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return res.status(200).json({
        success: true,
        message: "Thank you for your testimonial! Your feedback helps us improve our service."
      });
    } catch (error) {
      console.error("Error processing testimonial:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while processing your testimonial."
      });
    }
  });
  app2.post("/api/feedback", async (req, res) => {
    try {
      const result = feedbackFormSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          success: false,
          errors: result.error.errors
        });
      }
      const data = result.data;
      console.log("Feedback submission:", data);
      broadcastMessage("newFeedback", {
        id: Date.now().toString(),
        ...data,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return res.status(200).json({
        success: true,
        message: "Thank you for your feedback! We appreciate your input."
      });
    } catch (error) {
      console.error("Error processing feedback:", error);
      return res.status(500).json({
        success: false,
        message: "An error occurred while processing your feedback."
      });
    }
  });
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@db": path.resolve(import.meta.dirname, "db"),
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = 5e3;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
